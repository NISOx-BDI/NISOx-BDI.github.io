APACE
=====

Accelerated Permutation inference for the ACE model

Please see http://NISOx.org/Software/APACE

