function V = clone_vol(Vtemplate, fname, descrip)
% Clone volume based on a template; create cloned volume
% FORMAT V = clone_vol(Vtemplate, fname, descrip)
%
% Clones a volume, while discarding any information we don't want to
% clone.
%_______________________________________________________________________
% Version: http://github.com/NISOx-BDI/APACE/tree/6a2c5d4
%          2022-02-17 17:54:33 +0000

if iscell(Vtemplate)
    V = Vtemplate{1};
else
    V = Vtemplate(1);
end
V        = rmfield(V,{'fname','descrip','n','private'});
V.fname  = fname;
V.dim    = V.dim(1:3);
V.dt     = [spm_type('float32'), V.dt(2)];
V.pinfo  = [1 0 0]';
V.descrip= descrip;

V=spm_create_vol(V);

return

