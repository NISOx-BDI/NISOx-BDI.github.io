function x = ACEcode(ACE)
%
% Maps active (non-zero) ACE parameters to a integer code
%
%_______________________________________________________________________
% Version: http://github.com/NISOx-BDI/APACE/tree/6a2c5d4
%          2022-02-17 17:54:33 +0000

Code = [1 2 3];
x    = sum( Code(abs(ACE)>0) );

return

